-- =============================================
-- HASTANE ACİL SERVİS OTOMASYONU
-- VERİTABANI ŞEMASI (MANUEL TASARIM)
-- =============================================

CREATE DATABASE HastaneAcilServis;
GO

USE HastaneAcilServis;
GO

-- 1. HASTA TABLOSU
-- Hastaların temel bilgilerini tutar
CREATE TABLE HASTA (
    HastaID INT PRIMARY KEY IDENTITY(1,1),
    Ad NVARCHAR(50) NOT NULL,
    Soyad NVARCHAR(50) NOT NULL,
    TCKimlikNo NVARCHAR(11) UNIQUE NOT NULL,
    Cinsiyet CHAR(1),
    Yas INT,
    KanGrubu NVARCHAR(5),
    KayitTarihi DATETIME DEFAULT GETDATE()
);

-- 2. PERSONEL TABLOSU
-- Doktor, hemşire ve kayıt personelini tutar
CREATE TABLE PERSONEL (
    PersonelID INT PRIMARY KEY IDENTITY(1,1),
    Ad NVARCHAR(50) NOT NULL,
    Soyad NVARCHAR(50) NOT NULL,
    Unvan NVARCHAR(50), -- Doktor, Hemşire, Personel
    UzmanlikAlani NVARCHAR(100),
    Vardiya NVARCHAR(20),
    Durum NVARCHAR(20) DEFAULT 'Aktif',
    SonIslemZamani DATETIME
);

-- 3. ONCELIK_SEVIYESI TABLOSU (TRİYAJ)
CREATE TABLE ONCELIK_SEVIYESI (
    SeviyeID INT PRIMARY KEY,
    SeviyeAdi NVARCHAR(20), -- Kırmızı, Sarı, Yeşil
    RenkKodu NVARCHAR(10)
);

-- 4. BASVURU TABLOSU
-- Hastanın hastaneye geliş ve durum bilgisini tutar
CREATE TABLE BASVURU (
    BasvuruID INT PRIMARY KEY IDENTITY(1,1),
    HastaID INT FOREIGN KEY REFERENCES HASTA(HastaID),
    GelisSekli NVARCHAR(50), -- Ambulans, Ayaktan
    Sikayet NVARCHAR(MAX),
    OncelikDurumu NVARCHAR(20), -- Kırmızı, Sarı, Yeşil
    Durum NVARCHAR(30), -- Bekliyor, Aktif Hasta, Taburcu
    BasvuruTarihi DATETIME DEFAULT GETDATE(),
    GelisZamani DATETIME DEFAULT GETDATE(),
    CikisTarihi DATETIME
);

-- 5. YATAKLAR TABLOSU
CREATE TABLE YATAKLAR (
    YatakID INT PRIMARY KEY IDENTITY(1,1),
    OdaNo INT,
    YatakNo INT,
    Durum NVARCHAR(20) DEFAULT 'Boş', -- Boş, Dolu, Temizlikte
    OdaID INT
);

-- 6. YATIS TABLOSU
CREATE TABLE YATIS (
    YatisID INT PRIMARY KEY IDENTITY(1,1),
    HastaID INT FOREIGN KEY REFERENCES HASTA(HastaID),
    YatakID INT FOREIGN KEY REFERENCES YATAKLAR(YatakID),
    GirisZamani DATETIME DEFAULT GETDATE(),
    CikisZamani DATETIME,
    YatisTarihi DATE
);

-- 7. CIKIS TABLOSU
CREATE TABLE CIKIS (
    CikisID INT PRIMARY KEY IDENTITY(1,1),
    BasvuruID INT FOREIGN KEY REFERENCES BASVURU(BasvuruID),
    YatisID INT NULL,
    CikisZamani DATETIME DEFAULT GETDATE(),
    CikisTuru NVARCHAR(50), -- Taburcu, Vefat, Sevk
    Aciklama NVARCHAR(MAX)
);

-- 8. PERSONEL_HASTA_ATAMA TABLOSU
CREATE TABLE PERSONEL_HASTA_ATAMA (
    AtamaID INT PRIMARY KEY IDENTITY(1,1),
    PersonelID INT FOREIGN KEY REFERENCES PERSONEL(PersonelID),
    BasvuruID INT FOREIGN KEY REFERENCES BASVURU(BasvuruID),
    AtamaZamani DATETIME DEFAULT GETDATE(),
    Durum NVARCHAR(20) DEFAULT 'Aktif'
);

-- 9. ISLEM_KAYDI (DENETİM KAYITLARI)
CREATE TABLE ISLEM_KAYDI (
    LogID INT PRIMARY KEY IDENTITY(1,1),
    KullaniciID INT NULL,
    TabloAdi NVARCHAR(50),
    IslemTipi NVARCHAR(20),
    EskiDeger NVARCHAR(MAX),
    YeniDeger NVARCHAR(MAX),
    Aciklama NVARCHAR(MAX),
    HastaID INT NULL,
    IslemZamani DATETIME DEFAULT GETDATE()
);
